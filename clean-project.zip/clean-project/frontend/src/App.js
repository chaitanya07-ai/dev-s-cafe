import { useState, useEffect } from "react";
import axios from "axios";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

function App() {
  const [statusChecks, setStatusChecks] = useState([]);
  const [clientName, setClientName] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  // Fetch existing status checks on load
  useEffect(() => {
    fetchStatusChecks();
  }, []);

  const fetchStatusChecks = async () => {
    try {
      const res = await axios.get(`${BACKEND_URL}/api/status`);
      setStatusChecks(res.data);
    } catch (err) {
      console.error("Failed to fetch:", err);
    }
  };

  const handleSubmit = async () => {
    if (!clientName.trim()) return;
    setLoading(true);
    try {
      await axios.post(`${BACKEND_URL}/api/status`, { client_name: clientName });
      setClientName("");
      setMessage("Status check created!");
      fetchStatusChecks();
      setTimeout(() => setMessage(""), 3000);
    } catch (err) {
      setMessage("Error: " + (err.response?.data?.detail || err.message));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-xl mx-auto space-y-6">
        <h1 className="text-3xl font-bold">Status Checker</h1>

        <div className="flex gap-2">
          <input
            type="text"
            value={clientName}
            onChange={(e) => setClientName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
            placeholder="Enter client name..."
            className="flex-1 border border-input rounded-md px-3 py-2 text-sm bg-background"
          />
          <button
            onClick={handleSubmit}
            disabled={loading}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium disabled:opacity-50"
          >
            {loading ? "Saving..." : "Submit"}
          </button>
        </div>

        {message && (
          <p className="text-sm text-muted-foreground">{message}</p>
        )}

        <div className="space-y-2">
          <h2 className="text-lg font-semibold">Recent Checks</h2>
          {statusChecks.length === 0 ? (
            <p className="text-muted-foreground text-sm">No entries yet.</p>
          ) : (
            statusChecks.map((check) => (
              <div
                key={check.id}
                className="border border-border rounded-md px-4 py-3 text-sm"
              >
                <span className="font-medium">{check.client_name}</span>
                <span className="ml-2 text-muted-foreground">
                  {new Date(check.timestamp).toLocaleString()}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

export default App;
